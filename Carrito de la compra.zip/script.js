class Carrito {
    constructor(productos) {
        this.listaProductos = productos.products || productos; 
        this.unidades = {}; 
    }

    actualizarUnidades (sku, unidades) {
        this.unidades[sku] = Math.max(0, unidades); 
    }

    obtenerInformacionProducto(sku) { 
        const prod = this.listaProductos.find(p => p.SKU === sku);
        if (!prod) return null;

        return {
            sku: prod.SKU,
            quantity: this.unidades[sku] || 0
        };
    }

    obtenerCarrito() { 
        let total = 0; 
        const productosEnCarrito = [];

        this.listaProductos.forEach(prod => { 
            const cantidad = this.unidades[prod.SKU] || 0; 
            if (cantidad > 0) {
            total += parseFloat(prod.price) * cantidad;
            productosEnCarrito.push({ 
                sku: prod.SKU,
                title: prod.title,
                price: prod.price,
                quantity: cantidad
            });
            }
        });

        return { 
            total: total.toFixed(2), 
            currency: "€",
            products: productosEnCarrito
        };
    }
}



const API_URL = "https://jsonblob.com/api/jsonBlob/01a148e2-11bd-70b1-b65e-6aef991ba7d0"; 

let carrito; 

async function cargarTienda() { 
  const respuesta = await fetch(API_URL);
  const datos = await respuesta.json();

 
  carrito = new Carrito(datos);

  
  renderizarProductos(datos.products);
}


function renderizarProductos(productos) {
  const contenedor = document.getElementById("lista-productos");
  contenedor.innerHTML = "";

  productos.forEach(prod => {
    const fila = document.createElement("div");
    fila.classList.add("producto-fila");

    fila.innerHTML = `
      <div class="producto-info">
        <strong>${prod.title}</strong>
        <span class="ref">REF: ${prod.SKU}</span>
      </div>
      <div class="controles-cantidad">
        <button onclick="cambiarCantidad('${prod.SKU}', -1)">-</button>
        <span id="cant-${prod.SKU}">0</span>
        <button onclick="cambiarCantidad('${prod.SKU}', 1)">+</button>
      </div>
      <div class="precio-unitario">${prod.price}€</div>
      <div class="total-producto" id="total-${prod.SKU}">0.00€</div>
    `;

    contenedor.appendChild(fila);
  });
}


function cambiarCantidad(sku, cambio) {

  const infoActual = carrito.obtenerInformacionProducto(sku);
  const nuevaCantidad = infoActual.quantity + cambio;

  if (nuevaCantidad < 0) return;

  carrito.actualizarUnidades(sku, nuevaCantidad);

  document.getElementById(`cant-${sku}`).textContent = nuevaCantidad;

  actualizarPantalla();
}

function actualizarPantalla() {
  
  const estadoCarrito = carrito.obtenerCarrito();

  estadoCarrito.products.forEach(prod => {
    const totalFila = (parseFloat(prod.price) * prod.quantity).toFixed(2);
    const elTotalFila = document.getElementById(`total-${prod.sku}`);
    if (elTotalFila) {
      elTotalFila.textContent = `${totalFila}${estadoCarrito.currency}`;
    }
  });

  const contenedorResumen = document.getElementById("resumen-carrito");
  contenedorResumen.innerHTML = "";

  estadoCarrito.products.forEach(prod => {
    const linea = document.createElement("p");
    linea.textContent = `${prod.quantity} x ${prod.title} (${prod.quantity * prod.price}${estadoCarrito.currency})`;
    contenedorResumen.appendChild(linea);
  });

  document.getElementById("total-general").textContent = `${estadoCarrito.total}${estadoCarrito.currency}`;
}

cargarTienda();
